import { connection } from "./core/MinecraftTikTokBridge.js";
import { useTNTCoin } from "./extensions/tntcoin.js";
const { tiktok, minecraft } = connection;

useTNTCoin();

let giftCounter = 0;
let commandQueue = [];

function sendCommandWithRepeat(command, repeatCount) {
    for (let i = 0; i < repeatCount; i++) {
        commandQueue.push(command);
    }
}

function executeCommandWithDelay() {
    if (commandQueue.length > 0) {
        const command = commandQueue.shift();
        minecraft.sendCommand(command);
        setTimeout(executeCommandWithDelay, 1000); // Delay of 1 second (1000 milliseconds)
    }
}

tiktok.events.onGift((data) => {
    const { giftId, repeatCount, giftName, uniqueId, nickname } = data;
    if (data.repeatEnd) {
        minecraft.sendCommand(`tellraw @a {"rawtext":[{"text":"§a§l${data.nickname}§r§a§l sent §c§l${data.giftName}§r§a§l x${data.repeatCount}!"}]`);
        const message = JSON.stringify({
            uniqueId: data.uniqueId,
            nickname: data.nickname,
            giftName: data.giftName,
            giftId: data.giftId,
            giftCount: data.repeatCount,
        });
        switch (giftName) {
            case "Rose":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A ROSE TO\n §4SUMMON 1 layer!`);
                setTimeout(() => {
                    sendCommandWithRepeat(`/fill -5 15 1 -13 15 9 Sand`, repeatCount);
                }, 1000); // Delay of 1 second before summoning the mob
                break;
            case "Finger Heart":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A Finger Heart TO\n §4SUMMON 4 layer!`);
                setTimeout(() => {
                sendCommandWithRepeat(`/fill -13 19 9 -5 15 1 Sand`, repeatCount);
        }, 1000); // Delay of 1 second before summoning the mob
                break;
            case "Rosa":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A Rosa TO\n §4SUMMON 8 layer!`);
                setTimeout(() => {
                sendCommandWithRepeat(`/fill -13 23 9 -5 15 1`, repeatCount);
    }, 1000); // Delay of 1 second before summoning the mob
                break;
            case "Doughnut":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A Doughnut TO\n §4SUMMON 21 layer!`);
                setTimeout(() => {
                sendCommandWithRepeat(`/fill -13 29 9 -5 15 1`, repeatCount);
}, 1000); // Delay of 1 second before summoning the mob
                break;
            case "Perfume":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A Perfume TO\n §4SUMMON kulong!`);
                setTimeout(() => {
                    sendCommandWithRepeat(`/teleport @a 4.58 -4.00 5.19`, repeatCount);
                }, 1000); // Delay of 1 second before summoning the mob
                  break;
             case "GG":
                minecraft.sendCommand(`title @a title ${uniqueId}\n §1SEND A GG TO\n §4SUMMON tnt!`);
                setTimeout(() => {
                sendCommandWithRepeat(`/SUMMON TNT`, repeatCount);
                }, 1000); // Delay of 0 second before summoning the mob
                break;
        }

        giftCounter++;
        if (giftCounter % 1 === 0) {
            sendCommandWithRepeat(`run command`, 1);
            setTimeout(executeCommandWithDelay, 1000); // Delay of 1 second before executing the command
        }
    }
});

tiktok.events.onChat(data => {
    const { uniqueId, nickname, comment } = data;
    minecraft.sendCommand(`tellraw @a {"rawtext":[{"text":"§2${nickname} §7chat: §3${comment}"}]}`);
});

let totalLikes = 0;

tiktok.events.onLike(data => {
    const { uniqueId, nickname, likeCount } = data;
    
    totalLikes += likeCount;
    if (totalLikes >= 200){
    minecraft.sendCommand('tellraw @a {"rawtext":[{"text":"§4§lTHANKS FOR §6§l200LIKES!🌹🌹"}]}');
    minecraft.sendCommand(`/setblock -9 1 4`);
      totalLikes = 0
    }  
});